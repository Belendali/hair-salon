# Panic Salon · 女生 & 老爷爷模型交接

这一包以 **Demo 29 中已采用的两位角色造型**为基础，整理成真正可编辑的 Blender 网格、骨骼和表情动画。Demo 31 继续使用原来的网页角色；本资源包交给美术同事继续优化，不会替换 Demo。

## 文件

| 文件夹 | 角色 | 骨骼 | 动作 |
| --- | --- | --- | --- |
| girl | 长刘海女生 | 30 根 | 10 个：Idle、Walk、Sit、LookAround、ScratchHead、Pay、Happy、Angry、Talk、Sneeze |
| man | 秃顶老爷爷 | 30 根 | 9 个：Idle、Walk、Sit、LookAround、ScratchHead、Pay、Happy、Angry、Talk |

每个文件夹包含 `.blend` 源文件、`.glb` 导出、实际渲染预览、布料 PNG 贴图及 `model_report.json`。贴图同时打包进 Blender 文件。

## 在 Blender 中使用

1. 使用 Blender 4.2 或更新版本打开 `girl_rigged.blend` / `man_rigged.blend`。
2. 选择 `GIRL_RIG` / `MAN_RIG`，进入 Pose Mode，可调整身体、手臂、腿与手指骨骼。
3. 在 Dope Sheet → Action Editor 中选择上表中的动作，播放时间轴。默认是 Idle，24 fps。
4. 角色表情通过骨架 Object 的 Custom Properties 控制：`Smile`、`Frown`、`Blink`、`Talk`，范围 0–1。表情由这些属性驱动网格 Shape Keys；Happy、Angry、Talk 动作已经带有对应表情关键帧。手动调整时先取消当前 Action，避免播放时被关键帧覆盖。
5. 双眼和眉毛的独立骨骼是后续精修预留；当前表情主要由 Shape Keys 驱动。手指是每根一节的简化控制，没有逐指关节链。

## 网格与玩法素材

- `Face`：可继续修改的脸部网格，保留表情 Shape Keys。
- 女生 `Bangs_01`～`Bangs_18`：18 个独立刘海发束，方便改剪裁形状、长度和材质。
- 老爷爷 `charcoal-cheek-and-jaw-stubble`：下巴及脸颊胡茬；八字胡部件独立于皮肤。
- 老爷爷 `Graft_Tuft_1`～`Graft_Tuft_4`：可选植发发束，Blender 渲染默认隐藏。GLB 不保留 Blender 的渲染隐藏开关，接入时请按名称控制显示。
- `UpperSleeve_*`、`ForeSleeve_*`、`Palm_*`、`Finger*`：袖子、手掌与手指分开管理。
- 材质按 Skin / Hair / Beard / Sweater / Denim 等含义命名。演示网格本身的分块保留，方便同事逐部分融合和重拓扑。
- Studio 灯光、地面和相机保留在 `.blend` 中；GLB 只包含角色。

## 已验证

- 两份文件都包含实际蒙皮，每个顶点的骨骼权重总和为 1。
- Happy / Angry / Talk 动作会驱动对应表情，不只是动作名称。
- GLB 包含一个 Skin、30 根骨骼以及骨骼和面部 weights 动画通道。
- 两位角色的静态外观已实际渲染检查。

## 同事后续优化重点

这是**可编辑且可驱动的交接初版**。动作是供继续加工的草稿，不是电影级完成动画。

优先处理网格部件连接、肩肘和膝盖形变、手与头部接触、嘴部拓扑、手指关节，以及衣服穿插。头发目前是实体发束，并非毛发系统。腿部材质/轮廓仍沿用网页原型。眼睛和眉毛预留骨骼尚需按新的面部拓扑精修权重。

## 重建

`build_clients.py` 从 `girl-source.json.gz` 和 `man-source.json.gz` 重建两位角色；运行后再执行 `finalize_clients.py`，完成材质命名、导出整理和权重/表情验证。两个脚本应在 Blender 的独立新进程中运行，会替换当前场景；已有的手工修改请另存后再使用。

`export-clients.mjs` 是项目中的原始几何提取脚本，依赖 Panic Salon 代码仓库；日常编辑已有 `.blend` 不需要它。
