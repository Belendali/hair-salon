# Granny V3 — Game model, Demo 30

The editable Blender asset replaces the procedural granny in Demo 30. V1 and V2 are preserved in the previously delivered asset kit. Earlier playable demos keep their own code and assets.

- `build_granny.py`: deterministic Blender 4.2 rebuild script (run in a fresh scene).
- `granny_v3.blend`: mesh, matte materials, 23-bone rig, facial morphs and named clips.
- `granny_v3.glb`: runtime export; copied byte-for-byte to `dist/assets/granny-v3.glb`.
- `granny_preview.png`, `granny_face.png`: Blender appearance previews.
- `model_report.json`: actual export statistics and neutral front-frame clearance.

## Changes

Gold rims sit forward of the face; the raised bridge and curved temples are weighted to a dedicated glasses bone. Matte copper hair keeps roughness 0.84. The eye whites, irises, pupils and highlights close together. Arms use a more open rest pose and torso weights keep the chest stable during arm raises. Compatible rigid mesh parts are merged by material to reduce draw calls.

## Runtime mapping

| State | Pose and feedback |
| --- | --- |
| Walk in | Walk clip, side-on scene movement, synchronized footsteps |
| Sit and speak | Walk → Idle crossfade, blended leg bend, head turn, mouth morph rhythm |
| Service idle | Breathing, head turns, layered head/cheek/ear scratches and glasses adjustment |
| Correct pluck | Smile + raised cheeks, spring reaction |
| Wrong pluck | Frown, squint, ouch and brief head reaction |
| Payment | Stand-up framing, right-hand IK reach, existing money transfer |
| Walk out | Happy/Angry → Walk crossfade |
| Results | Happy/Angry clip and facial morph blend, raised or frustrated arms, existing confetti/flames |

`dist/granny-rig.mjs` owns animation blending and two-bone arm IK. `portrait` is attached to the head bone while preserving the game's original hair coordinates. There is one continuously loaded skinned model, so state changes do not swap between disconnected poses. Startup awaits the GLB; failed loads show a retry screen.

## Remaining limits

This is a playable rigged prototype, not feature-film animation quality. Face retopology, mouth interior and fingers remain simplified; no cloth simulation. Fine Blender shader textures are not baked to GLB. Runtime render checks validate deformed geometry and state logic; actual camera permissions, mobile GPU rendering and feel still need device playtesting.

Loader: official Three.js r180 `GLTFLoader` and `BufferGeometryUtils`, distributed under the existing MIT license in `dist/vendor/THREE-LICENSE.txt`. https://github.com/mrdoob/three.js/tree/r180/examples/jsm
