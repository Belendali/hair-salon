import bpy, math, os, json
from mathutils import Vector
from math import sin,cos,exp,pi
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24
scene.render.resolution_x=900;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
scene.world.color=(.20,.20,.20)
char=[]; bindings={}
def mat(name,color,rough=.5,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Roughness'].default_value=rough;n.inputs['Metallic'].default_value=metal;return m
skin=mat('Skin • warm peach',(.68,.36,.23),.52);skin.node_tree.nodes.get('Principled BSDF').inputs['Subsurface Weight'].default_value=.09
hair=mat('Hair • matte copper red',(.29,.032,.018),.84)
hair_bsdf=hair.node_tree.nodes.get('Principled BSDF')
hair_bsdf.inputs['Specular IOR Level'].default_value=.18
hair_bsdf.inputs['Coat Weight'].default_value=0
# Subtle directional fiber relief. Roughness/specular also survive the GLB export.
hn=hair.node_tree.nodes;hl=hair.node_tree.links
tc=hn.new('ShaderNodeTexCoord');mapping=hn.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(36,36,2)
noise=hn.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=4;noise.inputs['Detail'].default_value=2;noise.inputs['Roughness'].default_value=.55
bump=hn.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.08;bump.inputs['Distance'].default_value=.008
hl.new(tc.outputs['Generated'],mapping.inputs[0]);hl.new(mapping.outputs['Vector'],noise.inputs['Vector']);hl.new(noise.outputs['Fac'],bump.inputs['Height']);hl.new(bump.outputs['Normal'],hair_bsdf.inputs['Normal'])
gold=mat('Frames • satin gold',(.55,.36,.095),.27,.7)
knit=mat('Sweater • dusty rose',(.40,.115,.105),.84);skirtmat=mat('Skirt • burgundy',(.23,.064,.088),.85)
black=mat('Shoes',(.025,.03,.033),.4);white=mat('Eye white',(.88,.83,.71),.32);iris=mat('Iris sage',(.11,.17,.13),.32);pupil=mat('Pupil',(.008,.011,.009),.3);lip=mat('Lips',(.38,.105,.085),.56);blue=mat('Blue earrings',(.08,.30,.44),.25,.3)
# Fine shader texture is kept in .blend; GLB uses the flat base materials.
for m,scale,strength in [(knit,105,.12),(skirtmat,75,.06),(skin,155,.018)]:
 nodes=m.node_tree.nodes;links=m.node_tree.links;noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=scale;bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=strength;bump.inputs['Distance'].default_value=.025;links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],nodes.get('Principled BSDF').inputs['Normal'])
def uv(name,loc,scale,m,bone='head'):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=24,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 char.append(o);bindings[o.name]=bone;return o
def tube(name,points,r,m,bone='head'):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=12;c.bevel_depth=r;c.bevel_resolution=3;s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for p,co in zip(s.bezier_points,points):p.co=co;p.handle_left_type=p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);scene.collection.objects.link(o);o.data.materials.append(m);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False);char.append(o);bindings[o.name]=bone;return o
def merge_remesh(name,objs,voxel,iterations=5):
 bpy.ops.object.select_all(action='DESELECT')
 for o in objs:o.select_set(True)
 bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object;o.name=name
 mod=o.modifiers.new('Unified surface','REMESH');mod.mode='VOXEL';mod.voxel_size=voxel;mod.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=mod.name)
 mod=o.modifiers.new('Soft anatomical transitions','SMOOTH');mod.factor=.65;mod.iterations=iterations;bpy.ops.object.modifier_apply(modifier=mod.name)
 o.data.materials.clear();o.data.materials.append(skin if name=='Face_Continuous' else knit)
 bindings[o.name]='head' if name=='Face_Continuous' else 'spine';return o
# A single connected face/bridge/nose/ear/neck surface, not intersecting display parts.
parts=[uv('face',(0,0,5.18),(.68,.48,.94),skin),uv('chin',(0,-.08,4.58),(.48,.40,.34),skin),uv('bridge',(0,-.43,5.25),(.16,.20,.41),skin),uv('nose',(0,-.58,5.05),(.17,.26,.31),skin),uv('neck',(0,.015,4.30),(.205,.21,.40),skin)]
for side in [-1,1]:
 parts += [uv('cheek',(side*.38,-.17,4.92),(.22,.20,.29),skin),uv('ear',(side*.69,0,4.97),(.20,.12,.29),skin)]
face=merge_remesh('Face_Continuous',parts,.025,16)
# Face shape keys are broad deformation controls, not a production FACS rig.
face.shape_key_add(name='Basis')
for name in ['Smile','Frown','CheekRaise','BrowAngry','JawOpen','Ouch']:
 key=face.shape_key_add(name=name)
 for v,k in zip(face.data.vertices,key.data):
  w=face.matrix_world@v.co;x,y,z=w
  front=exp(-((y+.43)/.4)**2);mouth=exp(-((z-4.70)/.22)**2)*exp(-((abs(x)-.24)/.24)**2)*front
  if name=='Smile':k.co.z+=.12*mouth;k.co.x+=.055*mouth*(1 if x>0 else -1)
  if name=='Frown':k.co.z-=.10*mouth
  if name=='CheekRaise':k.co.z+=.09*exp(-((abs(x)-.37)/.25)**2-((z-4.94)/.25)**2)*front
  if name=='BrowAngry':k.co.z-=.08*exp(-((abs(x)-.22)/.25)**2-((z-5.60)/.18)**2)*front
  if name=='JawOpen':k.co.z-=.15*exp(-((z-4.56)/.30)**2)*front
  if name=='Ouch':k.co.x*=1-.045*exp(-((z-5.1)/.8)**2)
# Eyes, shaped lids, readable pupils and fine brow control bones.
for side,suffix in [(-1,'L'),(1,'R')]:
 cx=side*.285
 uv('Eye_'+suffix,(cx,-.448,5.48),(.225,.13,.215),white,'head')
 uv('Iris_'+suffix,(cx,-.568,5.47),(.087,.023,.103),iris,'eye.'+suffix)
 uv('Pupil_'+suffix,(cx,-.59,5.47),(.044,.011,.061),pupil,'eye.'+suffix)
 uv('EyeGlint_'+suffix,(cx-.024,-.601,5.509),(.021,.009,.021),white,'eye.'+suffix)
 lid=tube('UpperLid_'+suffix,[(cx-.215,-.47,5.48),(cx-.13,-.55,5.64),(cx+.10,-.55,5.66),(cx+.215,-.47,5.48)],.021,skin)
 lid.shape_key_add(name='Basis');key=lid.shape_key_add(name='Blink')
 for v,k in zip(lid.data.vertices,key.data):k.co.z-=max(0,(v.co.z-5.48))*1.90
 tube('Brow_'+suffix,[(cx-.20,-.49,5.76),(cx,-.54,5.81),(cx+.20,-.49,5.77)],.027,hair,'brow.'+suffix)
 uv('Earring_'+suffix,(side*.75,-.05,4.76),(.075,.072,.087),blue)
for o in list(bpy.data.objects):
 if o.type=='MESH' and o.name.startswith(('Eye_','Iris_','Pupil_','EyeGlint_')):
  o.shape_key_add(name='Basis');key=o.shape_key_add(name='Blink')
  for v,k in zip(o.data.vertices,key.data):k.co.z=(v.co.z+o.location.z-5.48)*.035+5.48-o.location.z
# Mouth line with genuine smile/frown morphs, so the seam follows expression.
mouth=tube('Mouth',[(-.24,-.452,4.71),(0,-.50,4.67),(.24,-.452,4.71)],.023,lip)
mouth.shape_key_add(name='Basis')
for name,d in [('Smile',.12),('Frown',-.13),('JawOpen',-.06)]:
 key=mouth.shape_key_add(name=name)
 for v,k in zip(mouth.data.vertices,key.data):k.co.z+=d*min(1,abs(v.co.x)/.24)
cavity=uv('MouthInterior',(0,-.525,4.65),(.155,.035,.015),mat('Mouth inside',(.095,.023,.028),.95))
cavity.shape_key_add(name='Basis');key=cavity.shape_key_add(name='Open')
for v,k in zip(cavity.data.vertices,key.data):k.co.z*=8
# Single bob shell with combed curves; no ball-like hair chunks.
verts=[];faces=[];rows=22;cols=64
for r in range(rows+1):
 v=r/rows
 for c in range(cols+1):
  a=-2.18+c/cols*4.36;rad=math.sqrt(max(.005,1-(1-min(1,v/.22))**2));verts.append((sin(a)*.78*rad,cos(a)*.55*rad+.025,6.18-1.73*v))
for r in range(rows):
 for c in range(cols):a=r*(cols+1)+c;faces.append((a,a+1,a+cols+2,a+cols+1))
me=bpy.data.meshes.new('BobShell');me.from_pydata(verts,[],faces);me.update();bob=bpy.data.objects.new('Hair_Bob',me);scene.collection.objects.link(bob);bob.data.materials.append(hair);char.append(bob);bindings[bob.name]='head'
for p in me.polygons:p.use_smooth=True
solid=bob.modifiers.new('Hair shell thickness','SOLIDIFY');solid.thickness=.035;bpy.context.view_layer.objects.active=bob;bpy.ops.object.modifier_apply(modifier=solid.name)
for i in range(46):
 a=-2.16+i/45*4.32;tube('CombedStrand_%02d'%i,[(sin(a)*.37,cos(a)*.30,6.08),(sin(a)*.78,cos(a)*.56,5.82),(sin(a)*.79,cos(a)*.56,5.17),(sin(a)*.75,cos(a)*.53,4.48)],.0035,hair)
for side in [-1,1]:
 for i in range(6):
  x=side*(.1+i*.10);tube('SweptFringe',[(side*.06,-.02,6.15),(x*.6,-.43,6.07),(x,-.51,5.87)],.018,hair)
# Frames sit in front of the nose, with a raised saddle and bent temples.
for side in [-1,1]:
 cx=side*.325
 pts=[(cx-.275,-.875,5.69),(cx+.275,-.875,5.69),(cx+.24,-.87,5.29),(cx-.21,-.87,5.29),(cx-.275,-.875,5.69)]
 tube('GoldFrame_'+str(side),pts,.014,gold,'glasses')
 tube('GlassesTemple_'+str(side),[(side*.60,-.875,5.69),(side*.80,-.32,5.64),(side*.84,.02,5.42),(side*.80,.11,5.28)],.012,gold,'glasses')
tube('GlassesBridge',[(-.07,-.877,5.67),(-.035,-.90,5.705),(0,-.91,5.715),(.035,-.90,5.705),(.07,-.877,5.67)],.014,gold,'glasses')
# One softened torso/shoulder knit shell, with articulated sleeves under it.
torso=[uv('torso',(0,.015,3.52),(.48,.29,.80),knit,'spine'),uv('collar',(0,.01,4.19),(.255,.25,.27),knit,'neck')]
for side in [-1,1]:torso.append(uv('shoulder',(side*.47,0,3.92),(.19,.20,.23),knit,'spine'))
merge_remesh('Sweater_Continuous',torso,.035,4)
# Narrow long skirt, shaped as a surface of revolution.
verts=[];faces=[]
for j,(z,r) in enumerate([(2.94,.43),(2.75,.48),(2.15,.49),(1.43,.53),(1.18,.54)]):
 for i in range(48):a=i/48*2*pi;verts.append((r*cos(a),r*.66*sin(a),z))
for j in range(4):
 for i in range(48):a=j*48+i;b=j*48+(i+1)%48;faces.append((a,b,b+48,a+48))
me=bpy.data.meshes.new('Skirt');me.from_pydata(verts,[],faces);o=bpy.data.objects.new('Skirt',me);scene.collection.objects.link(o);me.materials.append(skirtmat);char.append(o);bindings[o.name]='hips'
for f in me.polygons:f.use_smooth=True
for side,suf in [(-1,'L'),(1,'R')]:
 a=Vector((side*.47,0,3.94));b=Vector((side*.78,0,3.28));c=Vector((side*.94,-.02,2.70))
 upper=uv('SleeveUpper_'+suf,(a+b)/2,(.16,.18,(b-a).length/2+.10),knit,'upper_arm.'+suf);upper.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
 lower=uv('SleeveLower_'+suf,(b+c)/2,(.145,.16,(c-b).length/2+.10),knit,'forearm.'+suf);lower.rotation_euler=(c-b).to_track_quat('Z','Y').to_euler()
 uv('Hand_'+suf,(side*.94,-.04,2.58),(.135,.10,.20),skin,'hand.'+suf)
 for j in range(4):uv('Finger_'+suf,(side*.94+(j-1.5)*.048,-.044,2.43),(.031,.047,.11),skin,'hand.'+suf)
 uv('Calf_'+suf,(side*.24,0,.91),(.105,.12,.41),skin,'shin.'+suf)
 uv('Shoe_'+suf,(side*.24,-.12,.43),(.18,.30,.12),black,'foot.'+suf)
sleeves=[o for o in list(bpy.data.objects) if o.type=='MESH' and o.data.materials and o.data.materials[0]==knit]
merge_remesh('Sweater_Skinned',sleeves,.028,12)
# Deformation skeleton and explicit vertex groups. Not automated unweighted parenting.
bpy.ops.object.armature_add(location=(0,0,0));rig=bpy.context.object;rig.name='GRANNY_RIG';bpy.ops.object.mode_set(mode='EDIT');rig.data.edit_bones.remove(rig.data.edit_bones[0])
bones={}
def bone(name,a,b,parent=None):
 e=rig.data.edit_bones.new(name);e.head=a;e.tail=b
 if parent:e.parent=rig.data.edit_bones[parent]
 bones[name]=(Vector(a),Vector(b))
bone('root',(0,0,.35),(0,0,.8));bone('hips',(0,0,2.7),(0,0,3.1),'root');bone('spine',(0,0,3.1),(0,0,3.95),'hips');bone('neck',(0,0,3.95),(0,0,4.45),'spine');bone('head',(0,0,4.45),(0,0,5.7),'neck');bone('jaw',(0,-.1,4.9),(0,-.3,4.5),'head');bone('glasses',(0,-.88,5.67),(0,-.88,5.87),'head')
for side,suf in [(-1,'L'),(1,'R')]:
 bone('upper_arm.'+suf,(side*.47,0,3.94),(side*.78,0,3.28),'spine');bone('forearm.'+suf,(side*.78,0,3.28),(side*.94,-.02,2.70),'upper_arm.'+suf);bone('hand.'+suf,(side*.94,-.02,2.70),(side*.94,-.04,2.40),'forearm.'+suf)
 bone('thigh.'+suf,(side*.24,0,2.80),(side*.24,0,1.62),'hips');bone('shin.'+suf,(side*.24,0,1.62),(side*.24,0,.55),'thigh.'+suf);bone('foot.'+suf,(side*.24,0,.55),(side*.24,-.3,.40),'shin.'+suf)
 bone('eye.'+suf,(side*.285,-.44,5.48),(side*.285,-.66,5.48),'head');bone('brow.'+suf,(side*.285,-.45,5.76),(side*.285,-.60,5.76),'head')
bpy.ops.object.mode_set(mode='OBJECT');rig.show_in_front=True
for o in [x for x in bpy.data.objects if x.type=='MESH']:
 name=bindings.get(o.name,'head');g=o.vertex_groups.new(name=name);g.add(list(range(len(o.data.vertices))),1,'REPLACE')
 if o.name=='Sweater_Skinned':
  names=['spine','upper_arm.L','forearm.L','upper_arm.R','forearm.R'];groups={n:o.vertex_groups.get(n) or o.vertex_groups.new(name=n) for n in names}
  for v in o.data.vertices:
   pos=o.matrix_world@v.co
   arm=max(0,min(1,(abs(pos.x)-.34)/.24));arm=arm*arm*(3-2*arm)
   side='L' if pos.x<0 else 'R';fore=max(0,min(1,(3.50-pos.z)/.43));fore=fore*fore*(3-2*fore)
   weights={'spine':1-arm,'upper_arm.'+side:arm*(1-fore),'forearm.'+side:arm*fore}
   for n in names:groups[n].add([v.index],weights.get(n,0),'REPLACE')
 if o==face:
  neckg=o.vertex_groups.new(name='neck')
  for v in o.data.vertices:
   z=(o.matrix_world@v.co).z;w=max(0,min(1,(4.52-z)/.40))
   if w:g.add([v.index],1-w,'REPLACE');neckg.add([v.index],w,'REPLACE')
 mod=o.modifiers.new('Skin deformation','ARMATURE');mod.object=rig;o.parent=rig
groups={}
for o in list(rig.children):
 if o.type=='MESH' and not o.data.shape_keys:groups.setdefault(o.data.materials[0].name,[]).append(o)
for material_name,objects in groups.items():
 if len(objects)<2:continue
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join()
 o=bpy.context.object;o.name='Merged_'+material_name.split(' • ')[0].replace(' ','_')
# Deterministic geometric clearance check for every front rim/bridge vertex.
from mathutils.bvhtree import BVHTree
worldverts=[face.matrix_world@v.co for v in face.data.vertices]
bvh=BVHTree.FromPolygons(worldverts,[list(p.vertices) for p in face.data.polygons])
clearances=[]
for o in rig.children:
 if o.type=='MESH' and o.vertex_groups.get('glasses'):
  for v in o.data.vertices:
   if not any(g.group==o.vertex_groups['glasses'].index and g.weight>.9 for g in v.groups):continue
   pos=o.matrix_world@v.co
   if pos.y<-.84:
    co,normal,index,distance=bvh.find_nearest(pos);clearances.append(distance)
assert min(clearances)>.04, min(clearances)
print('FRAME_CLEARANCE',min(clearances))
# Named clips use eased interpolation, independent of the game runtime.
actions={}
for name,frames in [('Idle',72),('Walk',32),('Sit',40),('AdjustGlasses',60),('Happy',48),('Angry',48),('Talk',48)]:
 rig.animation_data_create();action=bpy.data.actions.new(name);rig.animation_data.action=action
 for f in range(1,frames+1,4):
  t=(f-1)/(frames-1);q=sin(t*2*pi)
  for pb in rig.pose.bones:pb.rotation_mode='XYZ';pb.rotation_euler=(0,0,0);pb.location=(0,0,0)
  rig.pose.bones['head'].rotation_euler.z=q*.06
  rig.pose.bones['spine'].rotation_euler.x=q*.012
  if name=='Walk':
   for side,suf in [(-1,'L'),(1,'R')]:rig.pose.bones['thigh.'+suf].rotation_euler.x=q*.24*side;rig.pose.bones['upper_arm.'+suf].rotation_euler.x=-q*.18*side
  if name=='Sit':
   k=t*t*(3-2*t);rig.pose.bones['root'].location.z=-.30*k
   for suf in ['L','R']:rig.pose.bones['thigh.'+suf].rotation_euler.x=-.8*k;rig.pose.bones['shin.'+suf].rotation_euler.x=1.1*k
  if name=='Happy':rig.pose.bones['root'].location.z=abs(q)*.15
  if name=='Angry':rig.pose.bones['head'].rotation_euler.z=q*.10;rig.pose.bones['brow.L'].rotation_euler.y=-.20;rig.pose.bones['brow.R'].rotation_euler.y=.20
  if name=='AdjustGlasses':rig.pose.bones['upper_arm.L'].rotation_euler.y=-1.5*sin(pi*t);rig.pose.bones['forearm.L'].rotation_euler.x=-1.7*sin(pi*t)
  if name=='Talk':rig.pose.bones['jaw'].rotation_euler.x=abs(sin(t*8*pi))*.10
  for pb in rig.pose.bones:pb.keyframe_insert('rotation_euler',frame=f);pb.keyframe_insert('location',frame=f)
 action.use_fake_user=True;actions[name]=action
 rig.animation_data.action=None;track=rig.animation_data.nla_tracks.new();track.name=name;strip=track.strips.new(name,1,action);track.mute=True
# Expression sample keys on face/mouth and blinking lids.
for o in [x for x in bpy.data.objects if x.type=='MESH' and x.data.shape_keys]:
 keys=o.data.shape_keys
 for k in keys.key_blocks:k.value=0
 keys.animation_data_create();act=bpy.data.actions.new(o.name+'_Expressions');keys.animation_data.action=act
 for k in list(keys.key_blocks)[1:]:
  for f,val in [(1,0),(16,1 if k.name in ['Smile','CheekRaise'] else 0),(32,1 if k.name in ['Frown','BrowAngry'] else 0),(48,1 if k.name in ['Blink','Ouch'] else 0),(64,0)]:k.value=val;k.keyframe_insert('value',frame=f)
 act.use_fake_user=True
 keys.animation_data.action=None
rig.animation_data.action=actions['Idle'];scene.frame_set(1);scene.render.fps=24
# Studio preview only; kept separate from exported character selection.
uv('StudioFloor',(0,0,.19),(200,200,.1),mat('Studio',(.20,.22,.23),.9),'root');floor=bpy.data.objects['StudioFloor'];floor.parent=None
for name,loc,power,size in [('Key',(-4,-5,8),850,5),('Fill',(4,-2,5),500,4),('Rim',(1,4,7),1000,3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,3.5))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(8,-15,7.1));cam=bpy.context.object;cam.name='PreviewCamera';cam.rotation_euler=(Vector((0,0,3.3))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=7.1;scene.camera=cam
scene.view_settings.view_transform='AgX'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'granny_v3.blend'))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in rig.children:o.select_set(True)
try:bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'granny_v3.glb'),export_format='GLB',use_selection=True,export_animations=True,export_nla_strips=True,export_skins=True,export_morph=True)
except Exception as e:print('GLB EXPORT ERROR',e)
scene.render.filepath=os.path.join(OUT,'granny_preview.png');bpy.ops.render.render(write_still=True)
# Closer face inspection to show junctions clearly.
cam.location=(4,-12,6.1);cam.rotation_euler=(Vector((0,-.1,5.15))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=2.9;scene.render.resolution_x=1000;scene.render.resolution_y=1000;scene.render.filepath=os.path.join(OUT,'granny_face.png');bpy.ops.render.render(write_still=True)
report={'blender':bpy.app.version_string,'hair_material':{'roughness':.84,'specular_ior_level':.18,'coat_weight':0,'micro_relief':'Blender only, not baked'},'bones':list(bones),'actions':list(actions),'face_shape_keys':[k.name for k in face.data.shape_keys.key_blocks],'glasses_min_clearance':min(clearances),'mesh_count':len(rig.children),'vertices':sum(len(o.data.vertices) for o in rig.children if o.type=='MESH'),'limitations':['Prototype weighting, not production retopology','Procedural fabric shader is Blender-only; GLB needs texture baking','Jaw bone not yet linked to face shape keys','Integrated with runtime IK and face morph blending in Demo 30']}
open(os.path.join(OUT,'model_report.json'),'w').write(json.dumps(report,indent=2))
print('MODEL_COMPLETE')
