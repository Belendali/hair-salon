# Panic Salon

A mobile-first camera game, part of Service Chaos. The user waits for the moving tweezers and taps to pluck the only white hair. A black hair ends the round with a disappointed client; an empty pinch returns to aiming.

## Implementation

- Static HTML, CSS and JavaScript, with locally vendored Three.js 0.180.0.
- Original procedural 3D client, separately animated facial features, deformable individual hair strands and articulating 3D tweezers.
- Camera opt-in, front-facing mirrored video, generated transparent barber cap and moustache stickers.
- MediaPipe Tasks Vision 0.10.22-rc.20250304 face landmarks in a classic Worker, using dynamic module import and local WASM/model files.
- No microphone, recording, image uploads, analytics service, account database or backend APIs in the game. A capped in-memory event log is exposed only for development.
- All game assets are served with the site. Font styles are locally hosted when the fetch completes; system font fallbacks remain defined.

## Running and validating

Serve `dist` from an HTTPS static host for mobile camera use. The site is deployed with Sites using `.openai/hosting.json`. Source is the tracked static directory; no build step is needed.

Run `node verify.mjs` for deterministic timing, targeting and geometry validation. Run `node --check` on authored JavaScript. These checks do not replace actual mobile camera, WebGL, touch or visual QA.

## Browser confidence

Implementation targets modern Safari and Chrome with WebGL2, WebAssembly, Workers, OffscreenCanvas and createImageBitmap. Camera denial or tracker failure preserves practice play. Actual iPhone and Android camera and performance testing remains to be completed by playing on the target devices; do not describe this source validation as a real-device pass.

The game reproduces the intended interaction and overall character style, not a pixel-identical recreation of an image-generation cover. No Nintendo characters, logos or assets are shipped.

## Dependencies

Three.js is MIT licensed. MediaPipe is Apache 2.0 licensed; model asset is from Google's published Face Landmarker model distribution. See `dist/vendor` for notices. Barber filter PNGs were created for this project. Sounds are synthesized locally.

## Visual revision

The neutral revision uses charcoal, grey, chrome, and a small chartreuse accent. Compact sans-serif captions and unboxed results keep the camera visible. The barber overlay is monochrome and the client wears a charcoal cape. Gameplay and targeting are preserved. The presentation references TikTok Effect House Tap And Catch (https://effecthouse.tiktok.com/learn/guides/tutorials/template-tutorials/tap-and-catch), not a claim about current popularity or a copied template.

## Demo 03

A slimmer tapered head with smaller facial features and no body. The client walks in horizontally with four footstep cues, settles into a seated pose, and only then reveals the tweezers. Layered procedural foley adds metallic closure, hair tension, pluck transient and seat impact. The expression moves gradually into an asymmetric, resigned smile. Target spacing and scan speed scale down together for the smaller head.

## Immutable playable iterations

`dist/demo-1` and `dist/demo-2` preserve the earlier committed applications. `dist/demo-3` preserves this update. `/versions/` is the comparison hub. The root opens the newest demo.

For each future iteration, edit the root application source, commit it, then run `python3 scripts/freeze_demo.py COMMIT demo-N` once. The script refuses to overwrite existing snapshots. It copies authored modules and styles into versioned paths and verifies shared vendor/assets against the source commit. Do not change a shared asset in place: use a new filename and preserve the old file. Update the hub and root page, commit and publish. No changes to historical demo directories.

Source checks cover geometry, hair continuity and the entrance sequence. Actual device audio, face tracking and visual polish still require mobile playtesting; this is an original prototype, not a TikTok or Nintendo product.


## Demo 04
Full body enters, then sits behind a real foreground counter. 3 unique white hairs among 15; all three must be removed to finish. Black hairs trigger a comic reaction and disappear, with no round failure. Scan speed 2.15–2.39 world units/sec; hit radius 0.125. Existing demo URLs remain immutable.

## Demo 05 — Barber tracking repair
Explicit OffscreenCanvas in worker, normalized WASM directory URL, main-page face detector fallback on initialization or repeated frame failure, frame watchdog, stale session cleanup and visible retry. Real landmarks are required; no fixed-position imitation filter. Gameplay unchanged.

## Demo 06
Original 150 BPM synth loop (not a licensed or verified trending TikTok recording). Locally synthesized libflite voices, bundled as WAV; speech synthesis fallback if unavailable. Success double-thump and cash sound. Third black pluck ends the service; completing 3 whites with at most 2 wrong plucks earns payment. Both exits show full-body standing and walking. Mute and pause stop music and voice.

## Demo 07
First granny art study: shaped elongated face, red bob with surface strands, gold glasses, pearl-blue earrings, sweater bump texture, skirt and shoes. Procedural model, not 1:1 production asset. Idle head motion and posed arm gestures use a shared motion clock paused during pluck; tool locks the rendered hair position. Continuous granny queue with pause control.

## Demo 08 — Granny visual refinement
- Dedicated granny-model module: continuous shaped face with integrated cheeks/chin and vertex blush, modeled ear folds, inset eyes with irises/catchlights and cat-eye glasses.
- Continuous skull-following hair cap and bob, tapered fringe, merged surface strands, ribbed sweater and floral skirt textures.
- Longer reference-led body proportions, two-segment posed arms and fingers. Portrait turns independently of body.
- Soft studio key/fill/rim lighting plus optional generated environment reflection.
- Idle gestures continue at reduced speed during pluck; selected tip is followed until detachment, then hair shrinks out before the next scan.
- Geometry inspected with a local software rasterizer (approximate shading); no actual browser/camera or mobile GPU visual verification. Existing mini-game rules and audio unchanged.
- All earlier demos retain their separate snapshots. This remains a procedural reconstruction, not a 1:1 source asset or film-quality rig.

## Demo 09 — Audio redesign
Original 156 BPM D-major 8-bar stereo score: syncopated bass, claps, offbeat chords and a call/response hook, with baked echo and soft saturation. Replaces the runtime minor-key square-wave loop; fallback is a quiet major-key motif. Full-sentence TTS removed: happy nonverbal hum and angry formant grumble. Short Oh no retained. Music playback phase survives pauses and music continues across the client handoff. All new sound assets are generated locally by scripts/audio/make_v9.py. Not a verified trending TikTok recording or a human voice recording.


## Demo 10 — Two-client service flow
- Bell → half-body side-on walk → turn/sit → short chatter and staggered hair rise → tool appears.
- Granny: 15 hairs / 3 white. Incorrect red hair plays a synthesized short “ouch” plus sigh; correct hair a quieter chime. Third mistake ends service without another attempt.
- Added cheek, ear and head-shake poses alongside scratching and adjusting glasses. Targets remain attached to the moving head.
- Client stands at the same scale, shows more sweater, hands over an engraved-style game banknote, and walks sideways out. Tips by wrong actions: 0 = $50, 1 = $30, 2 = $15, 3 = $5. Paid once per client; latest tip remains at upper right.
- Next bell brings in a brown-haired girl in a knit sweater and jeans. Three fringe sections, vertically moving scissors; tap at the lime guide. Each section retains its cut height; long, uneven and too-short outcomes are geometric changes. The two clients alternate continuously.
- Existing camera and barber face filter retained. Original Demo 9 groove retained. New voice assets in scripts/audio/make_v10.py (flite female short word plus original formant/breath effects; not human recorded voice).
- Validation: executable flow handlers in a mocked DOM, Three scene geometry/pose and target tests, offline geometry previews. No real phone camera/GPU/audio listening QA in this turn.
- Procedural real-time characters approximate the supplied references; not a 1:1 film-quality rig.


## Demo 11 — Service close-ups, deliberate scissors control, refined barber look
- Operating stage pushes into a 1.75x client, positioned at 0.76 world units above the bottom edge. Mouth and torso sit below the frame; eyes/hair remain visible. Counter hides during the close-up and returns for payment. Arrival and settlement retain their previous framing.
- Plucking range now ±3.12 world units with 0.145 hit tolerance and 2.2 units/sec scan, giving wider readable targets without increasing timing pressure.
- Girl: hold anywhere to catch the blade, drag vertically, release to snip. Minimum 0.20s hold; ±0.14 ideal-length tolerance plus ±0.11 consistency to the first successful section. An unsuccessful first section does not make the remaining sections impossible. The blade holds its screen height while the head moves. An intake-of-breath cue precedes the periodic 0.60s sneeze/head dip. The release pose is held through the snip for fair feedback. Pointer cancellation, pause and touch loss abort without cutting; Space hold + arrow keys + Space release also works.
- Two new transparent generated accessories, cap fabric/stitching/silver pin and slim charcoal moustache. Forehead and upper-lip anchors, yaw adjustment and time-based smoothing replace flat fixed placement. Selfie dark overlay reduced.
- No audio changed this edition. docs/AUDIO_BRIEF.md and /audio-brief/ provide the 19-file replacement brief (1 music, 8 shared effects, 10 character voices).
- Verified real flow handlers under a mocked DOM, cancellation and pause, filter bounds/lost-face cleanup, four phone aspect ratios, held blade vs head motion, and prior gameplay/exit geometry checks. Offline geometry preview used to inspect framing; no real phone camera/audio or browser GPU QA performed.

### Demo 11 accessory assets
Generated with built-in imagegen; original PNGs and alpha retained, source bounds selected in Canvas without modifying originals.
- dist/assets/barber-cap-v11.png: front-facing refined neutral pillbox barber cap, ivory fine fabric with charcoal band, tiny silver scissors pin, softly shaded 2.5D, subtle stitching, no thick outline/text/person, low wide profile, transparent background.
- dist/assets/barber-moustache-v11.png: front-facing slim charcoal handlebar moustache, fine hair texture and restrained elegant ends, softly shaded 2.5D, no face/person/text, transparent background.

## Demo 12 — Selfie entrance freeze fix
- Demo 11's overlay used lip landmark 0 and nose landmark 2, but neither tracker pipeline included them in its compact output. First face detection could throw inside the overlay renderer and prevent the next animation frame, leaving granny at the left edge.
- Worker, main-thread fallback and renderer now share the same validated landmark contract. Missing/corrupt packets skip the overlay. An unexpected overlay rendering exception exposes Retry while preserving game updates and frame scheduling. Camera restart/retry resets this isolated failure state.
- Versioned worker/module URLs avoid mixing cached Demo 11 tracker code with the updated renderer. Previous demo snapshots stay unchanged.
- Regression validation: actual worker frame-handler output and main-thread tracker output; compact tracker packet through the real filter and game frame handlers; left-side arrival through centered seated play and a successful pluck; malformed packets and injected overlay failure. Existing two-client service, payment, haircut and pause flow checks pass. Detector, DOM and Canvas are simulated; no physical-phone/browser camera test was performed.

## Demo 13 — Smaller service close-up
- Reduced the shared operating-stage character scale from 1.75 to 1.25 for both granny and the bangs client. Existing vertical placement, entrance/payment animation, controls, audio and Demo 12 tracking fix are retained.
- Prior demos remain independently playable; four-aspect-ratio geometry and target checks validate the revised scale.

## Demo 14 — One-swipe bangs
- Granny tweezers wait 0.65 world units higher (about 32 px on a 390 px wide viewport). Hair contact and pluck animation still reach the moving target. Both clients retain the 1.25x scale.
- Girl scissors rest on the right. Press the scissors, drag right to left with vertical steering, and release; reaching the left edge also ends the one allowed attempt. Reverse horizontal movement cannot recut. Early release, active-pointer cancellation and pause settle the partial haircut once; other pointers cannot interrupt it. Keyboard: hold Space, move with Left/Up/Down arrows, release Space.
- Eighteen individually cuttable fringe locks retain actual stroke heights. Ray/plane projection uses the current and previous portrait transforms, so head sways, side turns and warned sneezes change the resulting haircut. Segment interpolation covers fast swipes between events; coalesced touch points preserve curved gestures. Hair pieces fall at each cut.
- A 1.85-second reveal settles the head forward. Coverage, desired length and evenness determine feedback and existing $50/$30/$15/$5 tips; then payment, departure and the next client proceed. No second cut for that customer.
- Validation: real game handlers in a mocked DOM cover the service loop, both outcomes, pointer capture, early release, pause/cancel, multi-touch isolation and the selfie-entry regression. Geometry checks cover four phone aspect ratios, straight and crooked cuts, sneeze-altered cuts, fast full sweeps and no duplicate cuts. No physical-phone or browser GPU verification in this turn.

## Demo 15 — Clearer tools and gesture hints
- Girl-only service framing: scale 1.40 (previously 1.25), bottom offset 1.04 (previously 0.76). Granny remains at 1.25 with the raised tweezers. Entrance and payment keep their normal framing.
- Scissors enlarged 20% from 0.90 to 1.08, with the right start position adjusted slightly to keep the handles fully onscreen. The swipe anchor and pointer mapping use the same new layout.
- Removed the entire dashed haircut guide mesh. Cutting is freehand; actual stroke and client motion still determine the one-shot result.
- Lightweight neutral SVG hand demonstrations: a tap beside the moving tweezers, and a right-to-left swipe starting beside the scissors. Hints show in the waiting-to-play stage, hide immediately on first accepted input, remain absent during the rest of that service and reset for the next client. They never intercept input. Reduced-motion settings get a static hand and concise direction label.
- Existing four-aspect-ratio geometry checks include enlarged scissors staying onscreen. Actual flow handlers in a mocked DOM check hint modes and dismissal, service outcomes, swipe/pause/cancel handling, and selfie-entry protection. No browser or physical-phone visual test in this turn.

## Demo 16 — Three-client salon and hair transplant
- Tap/swipe/place hand demonstrations show for at most 3 seconds of active game time after tools become playable; an accepted action dismisses them earlier. Pause does not spend the remaining guidance time.
- Restored a subtle dashed ideal-length line on the girl's moving fringe, visible during cutting and the result reveal. The tip chip now reads TIP $amount / $50 with an accessible maximum.
- Added an original procedural balding male client based on the user's supplied three-view reference: slim head, broad eyes, dark horseshoe hair, small moustache, stubble tint, pink plaid shirt, denim overalls and posed limbs. Shared sculpt/cloth/lighting conventions maintain the existing art direction. This remains a procedural real-time approximation of the reference.
- Transplant play: six marked scalp spots, a draggable tuft on a small tray at the right, live hover feedback, and a release-time check against the moving scalp. Each correct drop fills one unique spot with a springy growing tuft. Misses fall away with a reaction; three mistakes end service. Pause/pointer cancellation preserve progress and do not consume an attempt. Keyboard: hold Space, move with arrows, release Space.
- Completing all six with fewer than three mistakes gives a happy reveal, payment, and departure; otherwise an angry exit. Existing tip schedule applies: 0/1/2/3 mistakes = $50/$30/$15/$5. Queue is granny → girl → man → granny. Existing sound effects and interim voices are reused with lower character pitch.
- Checks: actual game handlers in a mocked DOM verify timed hints, all three services, six successful grafts, third-miss exit, exact one-time payment, moving-target pointer placement, cancellation/pause and selfie-entry recovery. Geometry verifies four phone sizes, visible/reachable moving scalp targets and duplicate/miss rejection. Offline CPU rendering inspected the new client's in-game framing; no browser GPU or physical-phone QA in this turn.

## Demo 17 — Shift complete
- The three-client queue ends after the transplant client has paid and walked out. No fourth client arrives automatically. Replay and Pass the phone both begin a fresh shift at granny with cleared earnings.
- The final receipt adds the three actual one-time tip payments (up to $150). Count-up, a brief reward chord, cash ping, number bounce and restrained confetti create the finish. Individual client totals remain visible. Reduced-motion skips the count-up and visual animations.
- All gesture cues last at most two seconds; the swipe and drag demonstrations finish within that window.
- The supplied black-beard reference informs a parted near-black moustache, charcoal jaw and cheek stubble, matte surface strands merged into one mesh, and darker side hair. This refines the existing procedural character; it is not a claim of 1:1 asset reconstruction.
- Transplant mechanics are deliberately retained pending a discussion of timing/pressure, continuous planting or launch-and-land alternatives.
- Checked real game handlers in the existing mocked environment: $150 perfect and $15 worst shifts, stable final screen without a fourth arrival, exact payments, clean replay/pass-phone reset, two-second cues, and existing pointer/camera recovery. No physical-phone or browser visual QA was performed.

## Demo 18 — Pressure planting and wider selfie composition
- Replaces free-position drag/drop with an automatically positioned 3D planting pen. Hold anywhere in the play area (or hold Space) to charge; release in the visible green interval. Six successes finish the client; three shallow/deep attempts end service.
- Charge rate rises and the target interval narrows across six positions. A small rate variation follows the client's nodding rhythm; the visible meter is the source of truth at release. Overflow resolves once automatically; release, pointer loss or multitouch cannot duplicate a result. Pause/cancel discards only the uncommitted charge.
- Distinct feedback: a shallow tuft springs away, excessive pressure makes the client recoil with a warm scalp ring and ouch, and correct pressure grows the tuft with sparkles and a spring tone. Existing $150 shift settlement and two-second cues remain.
- Selfie video now uses object-fit: contain and object-position: 50% 26%, rather than filling/cropping the entire tall display. Shared camera-view.mjs supplies identical scale/offset math for the mirrored face overlay. Capture requests a preferred 3:4 front stream and no resize cropping where advertised. If track capabilities expose zoom, the minimum supported value is requested; an unsupported/rejected zoom does not block the camera. This does not promise access to the iOS Camera app's native wide-angle mode.
- Camera API references: https://w3c.github.io/mediacapture-image/ and https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia ; framing reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/object-fit .
- Verification: actual mocked game handlers cover green-window success, shallow/deep failure, held-pointer cancellation/pause, automatic overcharge, six correct attempts, three errors, and full shift/replay. Camera tests cover four phone layouts, mirror alignment, capabilities/fallbacks and denied permission; the pen fits at all six locations. No physical iPhone or live browser camera test was performed.

## Demo 19 — Stationary tap cue
- Granny's tap-hand cue is fixed at the horizontal center of the game instead of following the scanning tweezers. Its local tap animation and two-second timeout remain.

## Demo 20 — Aim, charge and fire
- The planting launcher stays fixed in the center of the view. Holding starts charging; a small finger drag steers the reticle with no snap or automatic next-spot alignment. The pen rotates around its fixed tip. Arrow keys steer the reticle for keyboard play.
- Releasing fires a visible hair plug. At release, both pressure and the actual moving, unfilled target must match. A short 140 ms flight precedes the single resolved impact; three mistakes end service. The shot target is fixed at release for fair feedback.
- Charge rate rises from 1.20 to 1.65 per second across six grafts (previously 0.57 to 0.92). Green windows narrow from 24% to 16%; hit radius is 0.26 world units. A pressure-correct but off-target shot fails.
- The sharp selfie retains the same uncropped dimensions and face-overlay transform. A second muted element shares the already-open stream as a blurred surround; feathered video edges replace the horizontal letterbox boundary. No second camera capture is requested. Both elements are cleared when the camera closes.
- Existing handler checks pass for the entire shift, manually aimed successful/failed shots, delayed one-time impact, fixed pen position, retained aim, cancellation and pause, and explicit selfie sizing/filter alignment. No physical-phone or live browser visual test.


## Demo 21 — Stop in the green

Transplanting now uses one tap to freeze an automatically bouncing timing marker inside the syringe barrel. No hold, drag, release, or manual aim. The enlarged syringe (1.14 scale, previously 0.88) follows the next empty graft location. Six successful grafts finish the service; three mistakes end it. The indicator moves at 1.35 to 2.00 normalized units per second; the green interval narrows from 24% to 16% after successive successes. The displayed value freezes immediately on pointer-down, with one delayed injection impact; waiting through a cycle does not spend an attempt. Pause freezes the meter. Guidance remains two seconds.

Game surface suppresses text selection, native drag, touch callout and context menus, preserving button/link controls. The transplant has no pointer capture or long-press dependency. Actual physical Chrome behavior has not been verified. Existing camera framing, barber filter, first two clients, tips and finite three-client shift remain.

Validation: actual game-frame/pointer handler tests cover both complete shifts ($150/$15), frozen tap values, bidirectional idle oscillation, automatic next targets, difficulty progression, pause/resume and duplicate-event protection. Geometry checks cover larger tool and embedded gauge at every site on four phone sizes; camera constraint and filter regression tests pass.

Independent snapshot: `/demo-21/`; Demo 20 remains at `/demo-20/`.


## Camera comparison — Demo 22 / Demo 23
A (`/demo-22/`) uses centered cover framing for a full vertical selfie, with no video edge mask or furniture. B (`/demo-23/`) retains the smaller contain framing and adds actual 3D charcoal leather chair, stitched backrest, chrome armrests and two narrow workstations with grooming props along the lower edges. The root opens B for evaluation; neither choice removes historical demos. Both use the same layout function for video and tracked face coordinates; all Demo 21 game rules remain. No physical camera device QA performed.


## Demo 24 — Four grafts and translucent syringe
Four actual scalp targets replace six. Per-success speed is 1.35 / 1.55 / 1.95 / 2.30 and green zone width is 24% / 21% / 16% / 13%. First-shot difficulty remains unchanged; last two are substantially harder. Three mistakes still end the service, with unchanged tips and shift settlement. Removed the visible pink mouth geometry under the old man's beard. The syringe has a wider transparent clear-coated barrel, inner fluid, finer metal nozzle, finger flange and graduation marks; its front timing gauge stays opaque for legibility. Uses camera option B; earlier A/B snapshots remain unchanged.


## Demo 25 — Full-screen camera and gentler final graft
Camera returns to full portrait cover with matched face-filter framing. Four grafts remain. Final green window increases from 13% to 16%, speed reduces from 2.30 to 2.00 (roughly 80 ms success window rather than 57 ms). Syringe grows from 1.14 to 1.36 scale and stays on a higher horizontal track (5.25 world units from bottom), smoothly following each target in x only. It stays upright; auto-aim and single-tap timing remain. Previous demos are preserved.


## Demo 26 — Full camera with salon furniture
Retains full portrait cover and Demo 25 gameplay. Furniture is now visible with the full camera: chair back moved behind the customer (negative z), armrests and stations remain low and lateral, with normal scene depth testing. The opaque floor strip is hidden for full camera so the live background is not replaced by a panel. Chair remains stationary when the character stands or walks away. Previous snapshots unchanged.


## Demo 27 — Furniture follows service framing
Chair and workstations now share the character's seated close-up scale and vertical pivot. They shift down as the character moves into service framing, preventing armrests from intersecting ears. Small seated horizontal movement follows the customer; walking entrance and departure do not drag the room, and furniture returns smoothly to the wide layout during stand-up. Full camera and gameplay unchanged.


## Demo 28 — Client reaction results and tip jar
Final success is strictly total > $130; $130 or below is failure (boundary made explicit). Three existing customer models return into a lower-screen lineup. Success uses jumping, happy expressions and falling confetti with the celebration sound; failure uses front-facing angry/unimpressed expressions and a negative voice/tone, with no confetti. The former opaque receipt card becomes an open selfie stage with a transparent 3D glass tip jar, falling banknotes, animated total, target label, replay and pass-phone. Service rules, individual tips and max $150 remain unchanged. Replay resets the three model transforms and hides the jar. Verified both full-shift outcomes, 129/130/131 boundary, lineup/jar visibility and reset.


## Demo 29 — Clear negative reactions and crown planting
Failed shift: grandma and man have animated orange/yellow flames above their heads and trembling angry poses; girl has animated blue tears. Effects are attached to portraits, hidden on success and cleared on replay. Timing rates 1.10/1.20/1.35/1.45, green widths 30/28/25/23 percent. Four sites now sample the upper scalp in X/Z across front/back crown quadrants rather than frontal X/Y hairline rows. Existing threshold, full camera, jar and version history preserved.


## Demo 30 — Rigged Blender granny
- Replaces the live granny with the new matte Blender GLB, retaining the girl, man and all existing game rules.
- Forward-set gold frames and a raised bridge remove the nose intersection; a dedicated bone keeps glasses with the head.
- Runtime clip crossfades, facial morph blending, complete eye blinks, arm IK for fidgeting/payment, and terminal happy/angry poses.
- Head-bone hair/effect anchor preserves pluck hit testing during motion. Startup awaits the asset and handles load failure.
- Editable model sources and export metadata: `model-sources/granny-v3/`. Earlier demos remain immutable.
- Verified actual GLB in full $150/$15 shifts, three errors, all three clients, pointer flows, replay and camera-filter fault recovery. Physical phone camera/GPU playtest remains with the user.


## Demo 31 — Individual client outcomes
- Restores the original Demo 29 character models, including granny. The Blender rig study remains available in Demo 30.
- Payment records persist each actual departure ending. Checkout uses that ending for each client's pose/effects, independently of the overall >$130 shift goal; cut bangs and planted grafts remain visible.
- Mixed-shift text reports happy-client count rather than calling all clients unhappy.
- Only graft #4 changes: rate 1.45 → 1.52, half-width .115 → .110; the first three levels stay the same.
- Verified the requested mixed path: angry granny + angry girl + perfect man → $60 total, with a happy planted man and no man flames.
- Separate colleague handoff assets: `model-sources/clients-v1/`; Blender and GLB models are not substituted into this demo.

## Demo 32 — character voice draft

Three separate local Flite voice profiles and authored phrase rhythms; 15 WAV cues, generated reproducibly by `scripts/audio/make_v32.py`. The sound is intentionally synthetic, not neural or actor-quality speech. Role/event routing replaces shared pitched recordings. A sneeze plays once per existing fidget cycle, synchronized with the warning; reactions duck music and pause/mute stops voices. `/voice-lab/` provides isolated auditions. Character art, game difficulty, and per-client result emotions are unchanged.

## Demo 33 — Bella audio selection

Uses all 15 uploaded MP3 sources with trimmed silences, balanced levels, original-speed character reactions, synchronized single footsteps, door sounds, a 64-second music edit and two result cues. Missing request/granny+girl happy cues carry over from Demo 32. `audio-sources/bella-v33/README.md` documents exact cuts and routing; raw sources are retained. `/voice-lab/` auditions the actual mix selection. Scoring, character appearance and individual result emotions are unchanged.


## Demo 34 — Happy clients decide the ending

Supersedes the earlier $130 shift goal: success requires all three distinct clients (granny, girl, man) to have a recorded happy departure. One shared decision now drives the result title, status, success/failure sound and confetti. Tips still tally into the jar out of $150 and never override client satisfaction. Each client keeps their individual departure expression. Success adds 30 lightweight lime, mint and white confetti pieces falling across the selfie; reduced-motion preferences suppress the effect.

Regression coverage: a real $115 shift with three happy clients celebrates once, a mixed $60 shift keeps the successful client's happy pose but plays the failure cue, and replay clears the result. Demo 33 remains available unchanged.


## Asset library — Kit 01 (Demo 34)

`/asset-library/` collects character BLEND/GLB bundles, the actual in-game character state preview, current and original audio, offline synth auditions, static prop GLBs/Three.js JSON, UI/filter sources, extracted cloth maps and the complete playable source. The game remains Demo 34 with no behavior changes. Earlier demos remain immutable.

Rebuild catalog assets in order: `node scripts/assets/export-scenes.mjs`, `node scripts/assets/export-prop-glb.mjs`, `python3 scripts/assets/render-synth.py`, `python3 scripts/assets/build-library.py`. UI previews are extracted from Demo 34. New asset versions should get a new kit number before replacing downloaded files.

Public downloads intentionally contain the game's editable resources requested for colleague handoff; credentials and hosting configuration are excluded from the source ZIP. See `dist/asset-library/files/HANDOFF.md` for the rig / runtime and procedural export distinctions.
