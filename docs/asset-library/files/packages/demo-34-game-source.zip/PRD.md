# Panic Salon 拔白头发 Demo 产品需求文档

版本：v0.1  
日期：2026 年 9 月 12 日  
所属主题：混乱的服务业 Service Chaos  
用途：第一版可玩 Demo 的设计与开发依据

Panic Salon 的第一版聚焦一次简单但令人紧张的服务：玩家看着自动横移的镊子，点击屏幕，争取只拔掉顾客头上唯一一根白头发。画面同时呈现真实玩家的自拍、跟随脸部的理发师装扮，以及前景可爱的 3D 顾客。体验的重点是点击准确、拔发有弹性、顾客反应好笑，玩家的真实反应能被清楚看到。

本文将已确认的方向和建议的首版默认值分开说明。所有时间、尺寸及性能数字均为开发起点或验收目标，尚未经过实际试玩验证。本文交付的是 PRD，不代表 Demo 已实现。

## 1 已确认的方向与首版默认值

### 已确认

- 产品是手机浏览器可打开的 HTML 游戏，竖屏优先。
- 背景显示前置摄像头中的真实玩家，并叠加跟随人脸的理发师特效。
- 前景为独立的 3D 顾客、很多头发、唯一一根白发和一把镊子。
- 镊子自动左右横移，玩家点击后下降夹发，无需真人手势操作。
- 拔到白发成功，顾客非常开心；拔到黑发有负反馈，顾客露出无奈表情。
- 造型可爱、诙谐，拔发与角色动作有柔软、有重量的弹性。
- 与已制作封面的奶油白、薄荷绿、粉色视觉保持一致。

### 本版建议采用的默认规则

- 拔到任意一根黑发，本局结束；保留拔错的证据，让玩家立即重试。
- 夹空不判失败，播放空夹动作，回到横移；夹空次数计入结果。
- 每局固定一根白发，不中途变色；本局内发位保持不变。
- 不设置倒计时、体力或生命值。先验证时机判断和反馈是否有趣。
- 一次操作锁定一根头发；拔发动画期间不接受新指令，也不排队执行连点。
- 单人即可完整体验。朋友可在旁观看或接过手机轮流玩；首版每次只跟踪一名玩家。

这些默认规则可通过配置调整，不作为用户已明确确认的新增要求。

## 2 这一版要验证什么

首次体验者看到白发和移动镊子后，应当很快理解“等对准，再点击”。玩家应能从画面解释自己为什么成功、为什么拔错；不能出现看似夹到白发却判黑发的情况。

完成一次拔发时，应有清楚的“夹住—蓄力—脱离—回弹”过程。拔错时，顾客的无奈和玩家的慌张形成反差；拔对时，顾客的开心具有奖励感。两种结果都应值得再看一次。

首版完成标准是能真实操作的完整小循环：打开页面、看到自己、开始、点击拔发、看到结果、重新开始。封面图只作为美术参考，不能代替实际运行的 3D 角色或跟脸效果。

## 3 页面与画面布局

以 390 × 844 CSS 像素作为设计参考，按手机实际可视区域自适应；构图接近 9∶16。横屏显示竖屏游戏容器，电脑使用居中的竖屏容器，鼠标和空格键均可触发拔发。

| 画面层 | 位置与内容 | 要求 |
| --- | --- | --- |
| 自拍背景 | 铺满游戏区域，玩家脸部主要位于上半部 | 保留真实肤质与表情；仅自拍画面镜像 |
| 理发师特效 | 玩家额头的奶油白薄荷绿帽子或发带，鼻下的小卷胡子 | 使用轻量 2D 图形，位置、角度和大小随脸变化；不遮眼睛 |
| 镊子 | 屏幕中部，夹尖在头发上方横移 | 银色主体、粉色握柄；3D 两片夹臂可开合；不出现持工具的手 |
| 顾客与头发 | 顾客占画面下方约 40%，发尖伸至中间区域 | 大头小五官，至少完整显示眼、鼻、嘴，便于读懂表情 |
| 游戏提示 | 顶部安全区域与底部少量按钮 | 文案短；按钮不遮玩家脸、镊子夹尖或白发 |
| 结果反馈 | 接着原场景显示短句与重试按钮 | 不用全屏结果页盖住真人和顾客的反应 |

主画面以真人、镊子、白发三个视觉焦点为主。白发使用象牙白，在黑色发丛间一眼可见；入场时闪一下帮助定位，开始后不持续闪烁。顾客肤色为温暖的浅桃色，眼睛是简洁椭圆，鼻子是圆润几何体；避免写实毛孔、密集发丝和复杂室内场景。

首版角色正面朝向镜头，平时自然微笑。瞄准期间只眨眼、呼吸和轻微上下浮动，不突然横向躲避。

## 4 从打开页面到再玩一局

1. **进入页面**：先显示顾客与镊子的静态预览。主按钮为“开启自拍并开始”，次按钮为“先试玩”。点击主按钮后请求摄像头权限，页面不自动申请麦克风。
2. **准备完成**：真人画面出现，理发师滤镜贴合脸部。显示“只拔白头发”，短暂强调目标白发。进入正式横移前留约 0.8 秒看清画面；开始按钮本身不能同时触发拔发。
3. **等待时机**：镊子匀速来回移动。玩家可点击任意非按钮区域，点击的位置不控制镊子的横坐标。
4. **执行拔发**：点击立即停止横移，镊子下降并夹合。命中则经历拉伸和拔出；夹空则空夹返回。
5. **播放反应**：白发成功，顾客开心回弹；黑发失败，顾客先愣住，再无奈地看向前方。自拍仍实时运行。
6. **显示结果**：动作开始后约 2.3 秒内展示结果按钮，玩家可选择“再来一次”或“换个人玩”。结果保留到玩家操作。
7. **重置**：恢复全部头发、顾客表情和特效；重新选择白发位置与镊子起始方向。摄像头权限正常时不重复申请。

“换个人玩”进入等待页面，暂停游戏；新玩家居中后点“准备好了”。首版不做双人同时控制、联网排名或强制两人入镜。

## 5 头发生成与命中判定

### 发型结构

头发分成装饰层与可夹取层。装饰层用于形成蓬松、密集的轮廓，位于后排或两侧，不进入镊子的夹取路径。前排有 11 根可夹取的粗细适中的发束，其中 10 根黑发、1 根白发。每根都有独立的根部、夹取点、颜色类型和是否已拔出状态。

前排的夹取点在水平方向彼此错开，不允许两根发束在屏幕中重叠到难以辨认。白发从内部 9 个位置中随机选择，避免贴近横移终点造成明显的难度差异。发根可沿头皮弧线分布，发尖高度略有变化。

### 点击判定

点击触发时，以**玩家刚刚看到的镊子夹尖位置**作为判定基准，记录该帧夹尖横坐标和所有可夹取点。比较夹尖与每个夹取点的水平距离：

- 距离在容错范围内，选择最近的一根头发，并立即锁定它的唯一 ID。
- 没有头发在容错范围内，则锁定为夹空。
- 两根距离相同，使用固定的 ID 顺序打破平局；不能偏向白发或按概率决定结果。
- 黑发与白发使用相同的容错范围。白发不因视觉更细而更难夹。

锁定后才播放下降动画。镊子可在容错范围内轻微对齐已选发束，使夹臂真正包住头发；不得吸附到容错范围之外的发束。其后所有动画与结果都使用同一个目标 ID，不在下降或回弹时重新计算命中。

镊子由两片夹臂组成，碰撞参考点始终是两夹尖的中点，而不是整个镊子模型的中心。自拍镜像、相机裁切与页面缩放不能改变游戏坐标。

### 起始参数

以下 W 为游戏可视容器宽度，H 为游戏可视容器高度；不是物理屏幕像素。

| 参数 | 建议初值 | 目的 |
| --- | --- | --- |
| 可夹取发束 | 11 根，其中 1 根白发 | 足够形成干扰，又保持可读性 |
| 夹取点横向范围 | 0.14W 至 0.86W | 对称留出左右空间 |
| 相邻夹取点间距 | 约 0.072W | 在 390px 宽时约 28px |
| 命中容错半宽 | 0.024W | 在 390px 宽时约 ±9.4px |
| 镊子横移速度 | 0.28W 每秒 | 单程约 2.6 秒；一次过点的有效点击窗口约 170ms |
| 速度可调范围 | 0.22W 至 0.38W 每秒 | 用试玩调节，首版不自动变速 |
| 待机头部浮动 | 不超过 0.005H | 保持生动，避免目标明显漂移 |
| 单次夹空往返 | 约 0.65 秒 | 不拖慢下一次尝试 |

瞄准阶段的动画应极轻，点击后将头部待机动作平滑接到拔发动作，不发生跳位。工程实现使用与帧率无关的时间推进；若渲染停顿超过约 250ms，暂停瞄准并等待恢复，不直接跳过目标。

## 6 操作结果与角色反馈

| 结果 | 头发与镊子 | 顾客 | 玩家特效与后续 |
| --- | --- | --- | --- |
| 拔中白发 | 白发完整留在夹尖，头皮对应位置恢复干净 | 眉毛抬起，眼睛变弯，大笑；头部开心弹一下 | 帽子轻弹，出现少量小星星；显示成功 |
| 拔中黑发 | 黑发留在夹尖，原处留小缺口；白发仍完整竖着 | 先短暂愣住，再半眯眼、嘴角歪一点，轻轻下沉 | 帽子歪一点、出现 2 至 3 滴汗；显示本局失败 |
| 夹空 | 夹尖合拢时没有头发，轻微弹一下后上升 | 眨一下眼，回到自然微笑 | 短促空夹声；继续横移，不判失败 |

笑点来自事情发生的后果。失败时必须同时看得到“镊子上的黑发”和“仍在头上的白发”，让观众无需看文字也知道拔错了。

真实玩家的慌张、专注和笑容来自其本人；不把玩家脸强行扭曲成预设表情。跟脸的汗珠和帽子可以根据游戏结果变化。

## 7 duang duang 动画规格

可爱弹性不是整颗头连续缩放。关键是物体依次受到力：夹臂闭合，发束绷紧，顾客头部略被带起，头发突然脱离，头部和其他发束先后回弹。各部分的动作有明确先后和衰减。

### 一次命中动作的时间轴

以点击为 0ms。以下是一套约 1.1 秒的起始节奏，可在联调时整体调整。

| 时间 | 动作 | 视觉验收 |
| --- | --- | --- |
| 0–70ms | 镊子停止横移，轻微抬起蓄势 | 点击有立即回应；不额外横滑 |
| 70–270ms | 镊子向已锁定发束下降 | 轨迹短、清楚，夹尖围住目标 |
| 270–370ms | 两夹臂闭合并轻压发束 | 看到真正夹紧，不穿模 |
| 370–550ms | 镊子上提，发束弯曲后绷紧，头部略被带起 | 有一点阻力和停顿，发根仍连在头皮 |
| 550ms 左右 | 发根脱离，播放“啵”声 | 画面中始终只有这一根发束，不出现复制或瞬移 |
| 550–720ms | 镊子带发束上弹，头部回落 | 头发留在夹尖，镊子不再穿过头皮 |
| 720–1100ms | 头部压扁回弹一次，其他发束错峰晃动 | 振幅逐次减小，最终稳定 |

### 形变与表演

- **发束**：使用少量骨骼或可变形曲线。拉起时主要由弯曲转为绷直，长度变化上限先设为约 15%，避免像橡皮糖无限拉长。脱离后继续跟随夹尖，有一次柔软摆尾。
- **头部**：根部受力时上提不超过约 0.015H；回落时纵向压缩约 4% 至 6%，横向适量展开，然后衰减至原形。眼鼻嘴跟随头部统一变形，不能浮在外面。
- **其余头发**：比头部迟约 40–80ms 回弹，左右发束稍有相位差，不齐刷刷一起摆动。首版不需要真实毛发物理模拟。
- **成功表演**：从发根脱离开始进入开心表情；一次额外的小弹跳、眉眼和嘴角联动，约 1 秒收稳。
- **失败表演**：先停约 250ms 像在确认发生了什么，再半眯眼、嘴角下移，头轻歪约 4°。无奈胜过大哭或夸张疼痛。
- **特效**：只用少量星星、汗滴或动作线，不用满屏粒子盖住玩家。

音效需与夹合、脱离和情绪转折同步：夹合轻“咔”、拔出短“啵”、成功轻铃、失败降调短音。提供静音按钮；静音后仅看动画也能识别三种结果。

## 8 状态与输入约束

| 状态 | 接受的操作 | 下一状态 |
| --- | --- | --- |
| 加载 | 资源失败时重试 | 准备页面或错误提示 |
| 准备页面 | 开启自拍、先试玩 | 规则提示 |
| 规则提示 | 等待短提示结束 | 横移瞄准 |
| 横移瞄准 | 点击游戏区或空格键 | 锁定并下降 |
| 锁定并下降 | 仅静音、退出等系统操作 | 命中拔出或夹空返回 |
| 命中拔出 | 不接受再次拔发 | 成功反应或失败反应 |
| 夹空返回 | 不接受再次拔发 | 横移瞄准 |
| 成功或失败反应 | 反应结束后开放结果按钮 | 结果展示 |
| 结果展示 | 再来一次、换个人玩 | 规则提示或换人准备 |
| 暂停 | 返回页面后点击继续 | 恢复先前状态 |

使用一次 pointerdown 作为一次触发，避免 touch 与 click 重复触发。多指、长按、动画期间连点均不产生额外拔发。静音、重试、权限等按钮不能穿透到游戏区。重试必须清理旧动画、音效调度和已锁定目标，不能让上一局回调改变新局结果。

页面进入后台时暂停游戏与推理。回来后先显示“继续”，再恢复保存的动作进度；不能在玩家看不到时判输赢。退出体验时停止摄像头媒体轨道。

## 9 自拍与理发师滤镜

首版使用人脸关键点跟踪来定位装扮，不需要识别玩家身份。装扮包括一个扁平理发帽或发带、一副小卷胡子，以及按游戏结果显示的汗珠或星星。

帽子锚定额头区域；宽度根据脸宽缩放，倾斜角根据双眼方向旋转。胡子锚定鼻下与上唇之间，跟随嘴部位置。帽子和胡子都需做时间平滑，轻微移动时不抖动，转头后不明显拖尾。所有图形先转换到与自拍裁切一致的坐标，再做一次镜像，不可重复翻转。

人脸暂时离开时，保留上一次位置不超过约 200ms，之后淡出装扮；重新检测到稳定人脸后恢复。游戏仍可点击游玩，丢脸本身不导致失败。首版提示玩家独自居中，朋友可在侧边观看；不把稳定双人识别列为验收要求。

摄像头权限被拒绝或设备没有摄像头时，提供“先试玩”，显示奶油色背景并保留完整 3D 玩法。模型加载失败但相机正常时，保留自拍、暂时关闭装扮，给出重试入口。该降级模式用于保证可玩性，不能被标记为“自拍滤镜已验收”。

摄像头画面与人脸关键点的处理设计为在设备端完成，不上传或存储人脸画面；首版也不申请麦克风，不默认录制。实际实现后应通过网络请求检查验证此要求。

## 10 开发与素材方案

### 建议实现方式

使用 Web 前置摄像头视频作为背景，透明的 Three.js 3D 画布绘制顾客、发束和镊子，单独的 2D 叠加层绘制跟脸装扮。游戏状态、命中逻辑和动画播放分离，防止动画卡顿影响结果。

人脸跟踪建议使用 MediaPipe Face Landmarker 的 Web 能力。官方文档提供人脸关键点与变换数据，适合定位脸部特效；其检测调用会同步阻塞调用线程，应优先评估 Worker，并限制推理频率，避免抢占拔发动画。参考：[MediaPipe Face Landmarker Web 文档](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker/web_js)。

手机公开体验链接需使用 HTTPS，摄像头由用户点击后授权；嵌入页面还要配置相机权限策略。参考：[MDN getUserMedia](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia)。浏览器内嵌环境的相机、模型加载与性能都需要真机验证，不预先承诺所有 TikTok 内置浏览器可用。

首个 3D 版本可以由代码生成圆润头部、五官、曲线发束和两片镊子，不必等待完整角色建模。模型质量之后可升级为 GLB；两种方式都必须具备可分离发束、可开合夹臂及可驱动表情，不能拿单张渲染图假装 3D。

### 最小素材清单

| 素材 | 最小配置 | 动画或技术要求 |
| --- | --- | --- |
| 顾客 | 1 个原创简洁 3D 头部，含眼睛、眉毛、鼻子、嘴 | 待机、开心、无奈；五官可分别驱动 |
| 发型 | 装饰发层、11 根可夹发束 | 每根独立 ID、夹取点和根部；黑白材质可切换 |
| 镊子 | 1 把银粉配色 3D 镊子 | 两片夹臂分开；定义夹尖中点和所夹发束挂点 |
| 理发师装扮 | 帽子或发带、卷胡子 | 透明背景的 SVG 或 PNG；可随脸缩放旋转 |
| 情绪图形 | 汗滴、小星星、少量动作线 | 各 1 套复用即可 |
| 音效 | 夹合、拔出、夹空、成功、失败 | 短、轻、不过响；使用可授权或自行合成的声音 |
| 界面 | 开始、重试、换人、静音及简短提示 | 适配安全区域和拇指触达 |

已有封面用于确认构图、材质和情绪，里面的真人不会作为每位用户固定的背景。角色设计需独立制作，吸收简洁派对游戏的表现方法，不直接抽取参考游戏的角色或商标。

### 首版范围

首版包含一名顾客、一种拔白发任务、自拍跟脸装扮、三种操作结果、重试与换人入口、静音和相机降级处理。剪刘海、植发、多顾客排队、难度系统、账户、排行榜和自动视频导出留到核心体验验证之后。

## 11 性能与兼容验收目标

- 优先在 iPhone Safari 与 Android Chrome 的竖屏真机验证；记录具体设备、系统及浏览器版本。
- 3D 动画目标 60fps；在选定测试机上连续运行时最低目标为稳定约 30fps。人脸推理从每秒 12–20 次起调，画面渲染单独进行。
- 点击后目标在 100ms 内看到停止横移或下降反馈；不能为了等待人脸推理而延迟接受点击。
- 渲染像素比先限制到 1.5，减少实时阴影与粒子；掉帧时先降装饰和推理频率，不改变命中范围或游戏速度。
- 加载时展示进度或当前步骤；游戏所需 3D 资源先就绪，相机和跟踪状态单独展示。不得显示未测量的加载完成时间。
- 适配 360px、390px、430px 宽的移动视口，以及电脑竖屏容器；处理浏览器地址栏变化和底部安全区。
- TikTok 内置浏览器单独列为待验证环境。遇到相机限制时，提供“用浏览器打开”的说明与可复制链接。

上述是目标，不是对未实现系统的性能声明。

## 12 测试与验收清单

### 核心机制

- [ ] 新的一局恰好有 1 根白发，所有可夹点均可到达，装饰发不会假扮可夹目标。
- [ ] 对准每一根头发点击，下降动作、最终拔出的发束与结果类型始终一致。
- [ ] 在容错边界内外分别点击，判定符合配置；不因头发颜色改变容错。
- [ ] 夹空后返回横移，白发和黑发均未被移除；黑发失败时白发仍可见。
- [ ] 连点、多指、长按和点击按钮不会重复拔发或跳过结果。
- [ ] 重试恢复发型、表情和输入状态，旧动作不会影响新局。
- [ ] 不同帧率与模拟卡顿下，游戏仍以玩家看到的夹尖位置判定。

### 动画与画面

- [ ] 正常速度下看得出夹紧、阻力、拔出、回弹四个动作阶段。
- [ ] 头发拔出前后连续，夹尖没有穿透头皮，发束不闪现或复制。
- [ ] 无奈表情具有短暂停顿和变化过程；成功表情明显更开心。
- [ ] 缩小到真实手机尺寸仍能找到白发，并看清玩家眼睛与顾客嘴部。
- [ ] 静音时仍能仅凭画面分辨成功、失败与夹空。

### 自拍与手机体验

- [ ] 实际打开前置摄像头，玩家能看到实时自拍，不使用预制真人视频代替。
- [ ] 帽子、胡子在轻微左右转头、靠近和远离时仍贴合，镜像与裁切一致。
- [ ] 拒绝权限、跟踪丢失、模型加载失败时有可理解且能继续操作的状态。
- [ ] 切到后台、返回、重试和换人均正常；退出后停止相机。
- [ ] 通过网络检查确认没有上传自拍帧或人脸关键点。
- [ ] 至少分别完成一台 iPhone 与一台 Android 真机的一整局成功、一整局失败及重试。

逻辑测试重点覆盖命中边界、目标锁定、输入防重复与重试清理；弹性、贴脸和喜剧节奏由真实运行画面与真机试玩验收，不能仅靠自动化测试证明。

## 13 Demo 试玩与下一步

先完成一条包含真实自拍、3D 顾客、自动移动镊子、点击拔发与两种结果的可玩流程，再用 5–8 位首次接触的体验者检查：是否在约 3 秒内理解规则、能否解释拔错原因、是否觉得拔出的手感舒服，以及是否主动愿意再玩一次。这些是定性验证建议，不作为已证实的传播指标。

试玩记录可以先保存在本地调试记录中，包括开始次数、成功次数、黑发失败次数、夹空次数、再次游玩和相机失败原因；不包含图像或人脸数据。观察到的问题应对应调参：容易误判则检查夹尖对齐与碰撞；难以成功则降低横移速度；动作沉闷则调整阻力停顿与回弹间隔；笑点不明显则延长无奈前的短暂停顿。

实现建议分为三步：先做 3D 玩法与确定性判定，再接入真实自拍和跟脸装扮，最后精修弹性、声音与手机性能。交付时应分别标记“可玩”“自拍已接入”“真机已验证”，只声明实际完成的部分。

本版最重要的验收画面是：镊子把一根黑发拔在半空，唯一的白发还留在头上；前景顾客从微笑变成无奈，背景玩家亲眼看到自己拔错后的真实反应。


## Demo 4 — 当前规则（替代此前单根白发 / 拔错结束规则）
- 客人完整身体步行入场，摆臂迈步；靠近坐下后由前景理发台遮住身体，身体模型始终保留。
- 每位客人 15 根可拔头发，其中随机 3 根白发。
- 点击使横向移动的镊子下降；落空可以重试。
- 拔错黑发：声音、无奈表情、搞笑吐槽；黑发移除，恢复操作，不结束游戏。
- 拔到白发：进度加一；3 根全部拔完才通关。
- 无生命限制、无倒计时；镊子速度从 2.15 随白发进度升至 2.39，命中半径 0.125。
- 结果显示错误拔发次数，可接待下一位客人或换朋友玩。
- Demo 1–3 保持原样，新增独立 Demo 4 链接。

## Demo 6 — 音乐与结局（替代无限容错规则）
- 150 BPM 原创合成舞曲循环；不是经核验的 TikTok 热榜原曲。
- 每次白发：清晰双击低音“咚咚”；每次黑发：合成人声“Oh no”。
- 累计第三根黑发立即结束本次服务，顾客生气站起、挥手吐槽、离开，不付钱。
- 3 根白发全部拔完且黑发错误不超过 2 根：满意站起、递钱、感谢、离开。
- 结果页在离场动画后展示，允许下一位客人或朋友接力。
- 音乐在语音时压低；静音、暂停、切后台停止音乐和人声。

## Demo 8 — 本轮优化
老奶奶采用独立模型模块：连续脸部曲面、完整短发体积、金色眼镜、织物纹理和分段手臂。服务中只转动头部，夹取期间小动作以降低的速度继续，镊子跟随选定头发直到拔离。保持三根白发成功、三次错误离场、连续接待。仍为程序重建角色，不标记为 1:1 或电影级成品。

## Demo 16：植发与三客人循环

第三位客人是参考图中的秃顶大叔，使用粉色格子衬衫、牛仔背带裤、小胡子和两侧头发。植发时以头顶为操作区：从右侧托盘拖出毛囊，跟随客人的转头、挠头动作瞄准空位，松手种入；一共补齐 6 处。种对后长出会回弹的发束，种错则掉落并给出负反馈，累计错误 3 次结束服务。成功填满后满意付款，失败则不满离开，统一按 0/1/2/3 次失误给 $50/$30/$15/$5。已填满的位置不能重复计分；取消触摸或暂停不消耗植发机会。

流程为：老奶奶拔白发 → 女生一刀剪刘海 → 大叔植发 → 下一轮。点击、滑动和拖动引导最多展示 3 秒，用户提前开始则立即消失。剪刘海标准虚线恢复，并保留到剪后展示；小费统一展示为 $实际金额 / $50。

## Demo 17：三关一局与收工结算
当前规则覆盖 Demo 16 的循环规则：老奶奶 → 刘海女生 → 植发大叔 → 收工。第三位客人付款离开后停止进客，展示当局三人的实际小费总额，满分 $150，最低 $15。每人只入账一次。数字累加后弹跳落定，伴随奖励音和少量彩纸；保留三项小费明细。再玩一次、换人玩都清空当局收入并从老奶奶开始。
点击、滑动、拖动提示最多 2 秒，操作后提前消失；短版演示能在两秒内完成一次。
植发角色按新参考图调整浓黑八字胡、黑灰下巴与两颊短胡茬、深色鬓角。植发操作暂不改，以下仅为待讨论候选，不属于本版已实现功能：
1. 力度植发：自动定位，按住蓄力、在合适力度松手；过浅弹出、过深惹怒、恰好长出头发。
2. 连续植发：按住连续种植，客人预告要动时及时松手，恢复稳定后继续。
3. 弹射毛囊：拉回瞄准、松手弹射，让毛囊落在晃动的秃顶上。

## Demo 18：蓄力植发与完整自拍取景
植发采用已选方案①，替代拖动毛囊：植发笔自动移动到下一个空位，玩家按住屏幕蓄力，进入绿色成功区时松手。共六处，后续蓄力更快、成功区更窄；蓄力速度随角色点头轻微变化。以屏幕当前显示的力度判定，保证反馈可解释。太浅：毛囊弹飞；太深：角色缩头、暖红提示、ouch；合适：弹性长发与闪光。三次失误结束服务，不论好坏均沿用本局三关与总收入结算。暂停、触摸取消不扣次数；持续按到底自动判为过深，后续松手不重复判定。
自拍优先请求竖向 3:4 前摄画面；展示时保留完整视频，不为铺满长屏裁掉左右画面。理发师滤镜与视频共用缩放和偏移。设备开放 zoom 能力时尝试最小值，失败保留正常摄像头；不承诺与 iOS 原生相机的广角范围完全相同。

## Demo 19：固定点击引导
第一关的小手指固定在画面水平中央，仅做原地点击示意，不跟随镊子左右移动；仍最多显示两秒。

## Demo 20：手动瞄准与快速发射
植发针固定在画面中央，按住蓄力，手指小幅滑动调整瞄准圈，松手发射毛囊。取消自动对准下一个位置。绿色力度和空位同时命中才成功，正确力度打偏也失败；判定采用松手时的位置，140ms 飞行后呈现效果和计分。蓄力明显加快，后半段进一步提速并缩窄绿色区。保留三次失误离场、三关总收入结算。
自拍人像大小不变，完整画面边缘渐隐接到同源虚化背景，消除底部横向硬边；人脸特效沿用同一缩放定位。


## Demo 21 — Stop in the green

Transplanting now uses one tap to freeze an automatically bouncing timing marker inside the syringe barrel. No hold, drag, release, or manual aim. The enlarged syringe (1.14 scale, previously 0.88) follows the next empty graft location. Six successful grafts finish the service; three mistakes end it. The indicator moves at 1.35 to 2.00 normalized units per second; the green interval narrows from 24% to 16% after successive successes. The displayed value freezes immediately on pointer-down, with one delayed injection impact; waiting through a cycle does not spend an attempt. Pause freezes the meter. Guidance remains two seconds.

Game surface suppresses text selection, native drag, touch callout and context menus, preserving button/link controls. The transplant has no pointer capture or long-press dependency. Actual physical Chrome behavior has not been verified. Existing camera framing, barber filter, first two clients, tips and finite three-client shift remain.

Validation: actual game-frame/pointer handler tests cover both complete shifts ($150/$15), frozen tap values, bidirectional idle oscillation, automatic next targets, difficulty progression, pause/resume and duplicate-event protection. Geometry checks cover larger tool and embedded gauge at every site on four phone sizes; camera constraint and filter regression tests pass.

Independent snapshot: `/demo-21/`; Demo 20 remains at `/demo-20/`.


## Camera comparison — Demo 22 / Demo 23
A (`/demo-22/`) uses centered cover framing for a full vertical selfie, with no video edge mask or furniture. B (`/demo-23/`) retains the smaller contain framing and adds actual 3D charcoal leather chair, stitched backrest, chrome armrests and two narrow workstations with grooming props along the lower edges. The root opens B for evaluation; neither choice removes historical demos. Both use the same layout function for video and tracked face coordinates; all Demo 21 game rules remain. No physical camera device QA performed.


## Demo 24 — Four grafts and translucent syringe
Four actual scalp targets replace six. Per-success speed is 1.35 / 1.55 / 1.95 / 2.30 and green zone width is 24% / 21% / 16% / 13%. First-shot difficulty remains unchanged; last two are substantially harder. Three mistakes still end the service, with unchanged tips and shift settlement. Removed the visible pink mouth geometry under the old man's beard. The syringe has a wider transparent clear-coated barrel, inner fluid, finer metal nozzle, finger flange and graduation marks; its front timing gauge stays opaque for legibility. Uses camera option B; earlier A/B snapshots remain unchanged.


## Demo 25 — Full-screen camera and gentler final graft
Camera returns to full portrait cover with matched face-filter framing. Four grafts remain. Final green window increases from 13% to 16%, speed reduces from 2.30 to 2.00 (roughly 80 ms success window rather than 57 ms). Syringe grows from 1.14 to 1.36 scale and stays on a higher horizontal track (5.25 world units from bottom), smoothly following each target in x only. It stays upright; auto-aim and single-tap timing remain. Previous demos are preserved.


## Demo 26 — Full camera with salon furniture
Retains full portrait cover and Demo 25 gameplay. Furniture is now visible with the full camera: chair back moved behind the customer (negative z), armrests and stations remain low and lateral, with normal scene depth testing. The opaque floor strip is hidden for full camera so the live background is not replaced by a panel. Chair remains stationary when the character stands or walks away. Previous snapshots unchanged.


## Demo 27 — Furniture follows service framing
Chair and workstations now share the character's seated close-up scale and vertical pivot. They shift down as the character moves into service framing, preventing armrests from intersecting ears. Small seated horizontal movement follows the customer; walking entrance and departure do not drag the room, and furniture returns smoothly to the wide layout during stand-up. Full camera and gameplay unchanged.


## Demo 28 — Client reaction results and tip jar
Final success is strictly total > $130; $130 or below is failure (boundary made explicit). Three existing customer models return into a lower-screen lineup. Success uses jumping, happy expressions and falling confetti with the celebration sound; failure uses front-facing angry/unimpressed expressions and a negative voice/tone, with no confetti. The former opaque receipt card becomes an open selfie stage with a transparent 3D glass tip jar, falling banknotes, animated total, target label, replay and pass-phone. Service rules, individual tips and max $150 remain unchanged. Replay resets the three model transforms and hides the jar. Verified both full-shift outcomes, 129/130/131 boundary, lineup/jar visibility and reset.


## Demo 29 — Clear negative reactions and crown planting
Failed shift: grandma and man have animated orange/yellow flames above their heads and trembling angry poses; girl has animated blue tears. Effects are attached to portraits, hidden on success and cleared on replay. Timing rates 1.10/1.20/1.35/1.45, green widths 30/28/25/23 percent. Four sites now sample the upper scalp in X/Z across front/back crown quadrants rather than frontal X/Y hairline rows. Existing threshold, full camera, jar and version history preserved.


## Demo 30 — Rigged Blender granny
- Replaces the live granny with the new matte Blender GLB, retaining the girl, man and all existing game rules.
- Forward-set gold frames and a raised bridge remove the nose intersection; a dedicated bone keeps glasses with the head.
- Runtime clip crossfades, facial morph blending, complete eye blinks, arm IK for fidgeting/payment, and terminal happy/angry poses.
- Head-bone hair/effect anchor preserves pluck hit testing during motion. Startup awaits the asset and handles load failure.
- Editable model sources and export metadata: `model-sources/granny-v3/`. Earlier demos remain immutable.
- Verified actual GLB in full $150/$15 shifts, three errors, all three clients, pointer flows, replay and camera-filter fault recovery. Physical phone camera/GPU playtest remains with the user.


## Demo 31 — Individual client outcomes
- Restores the original Demo 29 character models, including granny. The Blender rig study remains available in Demo 30.
- Payment records persist each actual departure ending. Checkout uses that ending for each client's pose/effects, independently of the overall >$130 shift goal; cut bangs and planted grafts remain visible.
- Mixed-shift text reports happy-client count rather than calling all clients unhappy.
- Only graft #4 changes: rate 1.45 → 1.52, half-width .115 → .110; the first three levels stay the same.
- Verified the requested mixed path: angry granny + angry girl + perfect man → $60 total, with a happy planted man and no man flames.
- Separate colleague handoff assets: `model-sources/clients-v1/`; Blender and GLB models are not substituted into this demo.


## Demo 34 — Happy clients decide the ending

Supersedes the earlier $130 shift goal: success requires all three distinct clients (granny, girl, man) to have a recorded happy departure. One shared decision now drives the result title, status, success/failure sound and confetti. Tips still tally into the jar out of $150 and never override client satisfaction. Each client keeps their individual departure expression. Success adds 30 lightweight lime, mint and white confetti pieces falling across the selfie; reduced-motion preferences suppress the effect.

Regression coverage: a real $115 shift with three happy clients celebrates once, a mixed $60 shift keeps the successful client's happy pose but plays the failure cue, and replay clears the result. Demo 33 remains available unchanged.
