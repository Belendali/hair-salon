# Earlier assets
Preserved comparisons; these sounds and original filter images are not active in Demo 34.
