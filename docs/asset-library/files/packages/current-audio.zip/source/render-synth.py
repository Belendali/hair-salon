"""Offline WAV auditions of Demo 34 synth cues. Formulas mirror game.js / soundtrack.mjs.
Noise and oscillator implementation differ from a browser; original source remains authoritative.
"""
import json,wave
from pathlib import Path
import numpy as np
from scipy.signal import lfilter
OUT=Path('dist/asset-library/files/synth');OUT.mkdir(parents=True,exist_ok=True);SR=44100
rng=np.random.default_rng(34)
def note(freq,end,dur,vol=.06,kind='sine',delay=0,attack=.008):
 t=np.arange(int((dur+.025)*SR))/SR;k=np.log(end/freq)/dur
 phase=2*np.pi*(freq*np.expm1(k*t)/k if abs(k)>1e-9 else freq*t)
 signal=np.sin(phase) if kind=='sine' else 2/np.pi*np.arcsin(np.sin(phase))
 env=np.where(t<attack,.0001*(vol/.0001)**(t/attack),vol*(.0001/vol)**(np.maximum(0,t-attack)/max(.001,dur-attack)))
 signal*=env*(t<dur)
 return np.pad(signal,(int(delay*SR),0))
def noise(dur,freq,vol,kind='bandpass',delay=0):
 n=int(dur*SR);x=rng.uniform(-1,1,n)*np.exp(-np.arange(n)/n*6)
 w=2*np.pi*freq/SR;a=np.sin(w)/(2*.8);co=np.cos(w)
 b=[a,0,-a] if kind=='bandpass' else [(1+co)/2,-(1+co),(1+co)/2]
 y=lfilter(np.array(b)/(1+a),np.array([1+a,-2*co,1-a])/(1+a),x)*vol
 return np.pad(y,(int(delay*SR),0))
def mix(*xs):
 y=np.zeros(max(map(len,xs)))
 for x in xs:y[:len(x)]+=x
 return y
positive=mix(note(880,1046.5,.11,.075,attack=.005),note(1320,1320,.14,.025,delay=.055,attack=.005))
specs=[
 ('positive','Correct action','White hair, a good cut or successful graft.',positive),
 ('sit','Sitting down','Client settles into the chair.',mix(noise(.12,380,.1),note(105,60,.15,.1))),
 ('tweezer-close','Tweezer click','The two arms close around a hair.',mix(noise(.033,4300,.13),note(2400,1100,.026,.028),note(820,230,.065,.035,'triangle'))),
 ('hair-tension','Hair tension','Hair stretches just before the pluck.',note(155,250,.17,.035,'triangle')),
 ('hair-pluck','Hair pop','The hair detaches; combines with a voice or reward.',mix(noise(.033,1900,.13),note(780,90,.12,.13),note(310,155,.075,.045,'triangle'),note(480,130,.11,.09),note(900,640,.055,.027,'triangle'))),
 ('empty-miss','Empty pluck','Tweezers missed every hair.',note(240,460,.09,.04)),
 ('scissor-snip','Scissor snip','Repeated while the scissors cut through bangs.',mix(*[mix(note(2100,480,.045,.1,'triangle',d,.005),noise(.15,6500,.20*.38,'highpass',d)) for d in [0,.09]])),
 ('graft-fire','Graft launch','Tap freezes the gauge and fires the tuft.',note(900,180,.075,.065,'triangle')),
 ('graft-hit','Graft impact','Low thump layered with the correct-action cue.',note(420,110,.18,.1)),
 ('graft-shallow','Too shallow','The tuft springs away; layered with the man’s sigh.',note(240,1150,.20,.06,'triangle')),
 ('graft-deep','Too deep','A low thud; layered with the man’s pain voice.',note(110,55,.16,.1)),
 ('cash','Payment chime','Client pays and the final total lands.',mix(note(1500,1500,.14,.08,attack=.005),note(2100,2100,.25,.07,delay=.11,attack=.005))),
 ('tally','Earnings count-up','Eight short ascending ticks during checkout.',mix(*[note(900+i*110,1100+i*100,.055,.025,delay=i*.11) for i in range(8)])),
]
manifest=[]
for id,label,use,x in specs:
 x=np.pad(x,(0,int(SR*.06)));p=OUT/(id+'.wav')
 with wave.open(str(p),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
 manifest.append(dict(id=id,label=label,use=use,url='/asset-library/files/synth/'+p.name,duration=round(len(x)/SR,3),source='Synth export',note='Offline audition; browser oscillators and random noise may sound slightly different. Edit game.js / soundtrack.mjs for the live cue.'))
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('Rendered',len(manifest),'synth cues.')
