# The gentleman — editable Blender handoff

These are rigged studies for refinement. Demo 34 continues to use procedural Three.js characters. The granny study differs from the accepted in-game granny. Use the in-game preview and game source as the appearance reference.

Open the BLEND in Blender 4.2+. GLB has a skeleton and animation clips; see model_report.json and the included guide. These are prototype rigs, not final production animation.
